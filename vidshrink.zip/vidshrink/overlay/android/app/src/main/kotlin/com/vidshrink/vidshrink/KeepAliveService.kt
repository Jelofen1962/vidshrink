package com.vidshrink.vidshrink

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager

/** Keeps the process alive (foreground service + CPU wake lock) while a job runs. */
class KeepAliveService : Service() {
    companion object {
        @Volatile
        var instance: KeepAliveService? = null
        const val CHANNEL = "vidshrink_job"
        const val ID = 4201
        const val DONE_ID = 4202
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Compression jobs", NotificationManager.IMPORTANCE_LOW)
        )
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vidshrink:job").apply {
            setReferenceCounted(false)
            acquire(12L * 60 * 60 * 1000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra("title") ?: "VidShrink"
        val text = intent?.getStringExtra("text") ?: ""
        startForeground(ID, build(title, text, -1, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }

    private fun openIntent(): PendingIntent {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        return PendingIntent.getActivity(
            this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun build(title: String, text: String, progress: Int, ongoing: Boolean): Notification {
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(if (ongoing) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setAutoCancel(!ongoing)
            .setContentIntent(openIntent())
        if (ongoing) {
            if (progress >= 0) b.setProgress(100, progress, false) else b.setProgress(0, 0, true)
        }
        return b.build()
    }

    fun update(title: String, text: String, progress: Int) {
        getSystemService(NotificationManager::class.java).notify(ID, build(title, text, progress, true))
    }

    fun finishWith(title: String, text: String?) {
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (text != null && title.isNotEmpty()) {
            getSystemService(NotificationManager::class.java)
                .notify(DONE_ID, build(title, text, -1, false))
        }
        stopSelf()
    }

    override fun onDestroy() {
        try { wake?.release() } catch (_: Throwable) {}
        instance = null
        super.onDestroy()
    }
}
