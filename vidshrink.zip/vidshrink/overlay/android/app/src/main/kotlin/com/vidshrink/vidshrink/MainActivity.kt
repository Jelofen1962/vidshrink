package com.vidshrink.vidshrink

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.provider.MediaStore
import android.util.Size
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.apache.commons.compress.archivers.sevenz.SevenZMethod
import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.tukaani.xz.LZMA2Options
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private lateinit var channel: MethodChannel
    private val main = Handler(Looper.getMainLooper())
    private val thumbPool = Executors.newFixedThreadPool(3)
    private val listPool = Executors.newSingleThreadExecutor()
    private val zipPool = Executors.newSingleThreadExecutor()

    private var pendingPerm: MethodChannel.Result? = null

    private var szOut: SevenZOutputFile? = null
    private var szPfd: ParcelFileDescriptor? = null
    private var szUri: Uri? = null

    @Volatile
    private var zipCancel = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "vidshrink/native")
        channel.setMethodCallHandler { call, result -> handle(call, result) }
    }

    private fun handle(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "ensurePermissions" -> ensurePermissions(result)
            "listVideos" -> bg(listPool, result) { listVideos() }
            "thumbnail" -> {
                val id = (call.argument<Number>("id") ?: 0).toLong()
                bg(thumbPool, result) { thumb(id) }
            }
            "freeSpace" -> result.success(StatFs(workDir().path).availableBytes)
            "workDir" -> result.success(workDir().absolutePath)
            "toBackground" -> {
                moveTaskToBack(true)
                result.success(null)
            }
            "serviceStart" -> {
                val i = Intent(this, KeepAliveService::class.java)
                i.putExtra("title", call.argument<String>("title") ?: "VidShrink")
                i.putExtra("text", call.argument<String>("text") ?: "")
                startForegroundService(i)
                result.success(null)
            }
            "serviceUpdate" -> {
                KeepAliveService.instance?.update(
                    call.argument<String>("title") ?: "VidShrink",
                    call.argument<String>("text") ?: "",
                    call.argument<Int>("progress") ?: -1
                )
                result.success(null)
            }
            "serviceStop" -> {
                KeepAliveService.instance?.finishWith(
                    call.argument<String>("title") ?: "",
                    call.argument<String>("text")
                )
                result.success(null)
            }
            "sevenZOpen" -> {
                val name = call.argument<String>("name") ?: "VidShrink.7z"
                val ultra = call.argument<Boolean>("ultra") ?: true
                bg(zipPool, result) { openArchive(name, ultra) }
            }
            "sevenZAdd" -> {
                val path = call.argument<String>("path") ?: ""
                val entry = call.argument<String>("entry") ?: File(path).name
                bg(zipPool, result) { addEntry(path, entry) }
            }
            "sevenZFinish" -> bg(zipPool, result) { finishArchive() }
            "sevenZAbort" -> bg(zipPool, result) { abortArchive(); null }
            "sevenZCancel" -> {
                zipCancel = true
                result.success(null)
            }
            else -> result.notImplemented()
        }
    }

    private fun bg(pool: ExecutorService, result: MethodChannel.Result, block: () -> Any?) {
        pool.execute {
            try {
                val r = block()
                main.post { result.success(r) }
            } catch (e: Throwable) {
                main.post { result.error("ERR", e.message ?: e.toString(), null) }
            }
        }
    }

    // ───────── permissions ─────────

    private fun mediaPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissions(result: MethodChannel.Result) {
        val need = ArrayList<String>()
        if (!granted(mediaPerm())) need.add(mediaPerm())
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isEmpty()) {
            result.success(true)
            return
        }
        pendingPerm?.success(false)
        pendingPerm = result
        requestPermissions(need.toTypedArray(), 4711)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 4711) {
            pendingPerm?.success(granted(mediaPerm()))
            pendingPerm = null
        }
    }

    // ───────── media library ─────────

    private fun workDir(): File {
        val base = getExternalFilesDir(null) ?: filesDir
        return File(base, "work").apply { mkdirs() }
    }

    private fun listVideos(): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        val m = MediaStore.Video.Media
        val proj = arrayOf(m._ID, m.DATA, m.DISPLAY_NAME, m.DURATION, m.SIZE, m.WIDTH, m.HEIGHT)
        contentResolver.query(m.EXTERNAL_CONTENT_URI, proj, null, null, "${m.DATE_ADDED} DESC")
            ?.use { c ->
                val iId = c.getColumnIndexOrThrow(m._ID)
                val iData = c.getColumnIndexOrThrow(m.DATA)
                val iName = c.getColumnIndexOrThrow(m.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(m.DURATION)
                val iSize = c.getColumnIndexOrThrow(m.SIZE)
                val iW = c.getColumnIndexOrThrow(m.WIDTH)
                val iH = c.getColumnIndexOrThrow(m.HEIGHT)
                while (c.moveToNext()) {
                    val path = c.getString(iData) ?: continue
                    val size = c.getLong(iSize)
                    if (size <= 0) continue
                    out.add(
                        mapOf(
                            "id" to c.getLong(iId),
                            "path" to path,
                            "name" to (c.getString(iName) ?: File(path).name),
                            "durationMs" to c.getLong(iDur),
                            "size" to size,
                            "width" to c.getInt(iW),
                            "height" to c.getInt(iH)
                        )
                    )
                }
            }
        return out
    }

    private fun thumb(id: Long): ByteArray? {
        return try {
            val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
            val bmp = contentResolver.loadThumbnail(uri, Size(256, 256), null)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            bos.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    // ───────── 7z archive (streamed, one file at a time) ─────────

    private fun openArchive(name: String, ultra: Boolean): String {
        abortArchive()
        zipCancel = false
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/x-7z-compressed")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VidShrink")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Cannot create the archive in Downloads")
        szUri = uri
        val pfd = contentResolver.openFileDescriptor(uri, "rw")
            ?: throw IllegalStateException("Cannot open the archive for writing")
        szPfd = pfd
        val sz = SevenZOutputFile(FileOutputStream(pfd.fileDescriptor).channel)
        if (ultra) {
            val opts = LZMA2Options(9)
            opts.dictSize = 16 shl 20
            sz.setContentMethods(listOf(SevenZMethodConfiguration(SevenZMethod.LZMA2, opts)))
        } else {
            sz.setContentCompression(SevenZMethod.COPY)
        }
        szOut = sz
        return "Download/VidShrink/$name"
    }

    private fun addEntry(path: String, entryName: String): Long {
        val sz = szOut ?: throw IllegalStateException("Archive is not open")
        val f = File(path)
        val total = f.length()
        sz.putArchiveEntry(sz.createArchiveEntry(f, entryName))
        var done = 0L
        var last = 0L
        FileInputStream(f).use { ins ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                if (zipCancel) throw InterruptedException("cancelled")
                val n = ins.read(buf)
                if (n < 0) break
                sz.write(buf, 0, n)
                done += n
                val now = System.currentTimeMillis()
                if (now - last > 400) {
                    last = now
                    val d = done
                    main.post {
                        channel.invokeMethod("zipProgress", mapOf("done" to d, "total" to total))
                    }
                }
            }
        }
        sz.closeArchiveEntry()
        return total
    }

    private fun finishArchive(): Long {
        val sz = szOut ?: throw IllegalStateException("Archive is not open")
        sz.finish()
        sz.close()
        val size = szPfd?.statSize ?: 0L
        szPfd?.close()
        val values = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        szUri?.let { contentResolver.update(it, values, null, null) }
        szOut = null
        szPfd = null
        szUri = null
        return size
    }

    private fun abortArchive() {
        try { szOut?.close() } catch (_: Throwable) {}
        try { szPfd?.close() } catch (_: Throwable) {}
        try { szUri?.let { contentResolver.delete(it, null, null) } } catch (_: Throwable) {}
        szOut = null
        szPfd = null
        szUri = null
        zipCancel = false
    }
}
