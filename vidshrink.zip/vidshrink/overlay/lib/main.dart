import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:dynamic_color/dynamic_color.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

const MethodChannel _native = MethodChannel('vidshrink/native');

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VidShrinkApp());
}

// ───────────────────────── helpers ─────────────────────────

String fmtBytes(num b) {
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  double v = b.toDouble();
  int i = 0;
  while (v >= 1024 && i < 4) {
    v /= 1024;
    i++;
  }
  final d = i < 2 ? 0 : (v < 10 ? 2 : 1);
  return '${v.toStringAsFixed(d)} ${u[i]}';
}

String fmtDur(num ms) {
  final s = (ms / 1000).round();
  final h = s ~/ 3600, m = (s % 3600) ~/ 60, sec = s % 60;
  String two(int n) => n.toString().padLeft(2, '0');
  return h > 0 ? '$h:${two(m)}:${two(sec)}' : '$m:${two(sec)}';
}

String fmtRate(num bps) => bps >= 1000000
    ? '${(bps / 1000000).toStringAsFixed(2)} Mbps'
    : '${(bps / 1000).round()} kbps';

final Map<int, Future<Uint8List?>> _thumbCache = {};
Future<Uint8List?> _thumbOf(int id) => _thumbCache.putIfAbsent(id, () async {
      try {
        return await _native.invokeMethod<Uint8List>('thumbnail', {'id': id});
      } catch (_) {
        return null;
      }
    });

Future<void> _deleteQuiet(String path) async {
  try {
    final f = File(path);
    if (await f.exists()) await f.delete();
  } catch (_) {}
}

Future<void> _svc(String method, [Map<String, dynamic>? args]) async {
  try {
    await _native.invokeMethod(method, args);
  } catch (_) {}
}

// ───────────────────────── models ─────────────────────────

enum Codec { hevc, h264 }

enum EncResult { ok, failed, cancelled }

class Vid {
  Vid({
    required this.id,
    required this.path,
    required this.name,
    required this.durMs,
    required this.size,
    required this.w,
    required this.h,
  });

  factory Vid.fromMap(Map<dynamic, dynamic> m) => Vid(
        id: (m['id'] as num).toInt(),
        path: m['path'] as String,
        name: m['name'] as String,
        durMs: (m['durationMs'] as num).toInt(),
        size: (m['size'] as num).toInt(),
        w: (m['width'] as num).toInt(),
        h: (m['height'] as num).toInt(),
      );

  final int id;
  final String path;
  final String name;
  int durMs;
  final int size;
  int w, h;
  double fps = 30;
  int vBps = 0;
  bool hasAudio = true;
  bool probing = false;
}

class Plan {
  Plan({
    required this.outW,
    required this.outH,
    required this.vBps,
    required this.aBps,
    required this.outDurMs,
    required this.bytes,
    required this.fps,
    required this.scaleTo,
    required this.landscape,
  });
  final int outW, outH, vBps, aBps, outDurMs, bytes;
  final double fps;
  final int? scaleTo;
  final bool landscape;
}

class JobResult {
  JobResult(this.ok, this.title, this.detail);
  final bool ok;
  final String title;
  final String detail;
}

// ───────────────────────── app ─────────────────────────

class VidShrinkApp extends StatelessWidget {
  const VidShrinkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return DynamicColorBuilder(
      builder: (ColorScheme? light, ColorScheme? dark) {
        final l = light ?? ColorScheme.fromSeed(seedColor: const Color(0xFF3F51B5));
        final d = dark ??
            ColorScheme.fromSeed(
                seedColor: const Color(0xFF3F51B5), brightness: Brightness.dark);
        return MaterialApp(
          title: 'VidShrink',
          debugShowCheckedModeBanner: false,
          themeMode: ThemeMode.system,
          theme: ThemeData(colorScheme: l, useMaterial3: true),
          darkTheme: ThemeData(colorScheme: d, useMaterial3: true),
          home: const HomePage(),
        );
      },
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const _levels = <int?>[null, 1080, 720, 480, 360];
  static const _levelNames = ['Original', '1080p', '720p', '480p', '360p'];

  final List<Vid> _vids = [];
  Future<void> _probeChain = Future.value();

  // settings
  int _quality = 2;
  Codec _codec = Codec.hevc;
  bool _hw = true;
  double _speed = 1.0;
  bool _ultra = true;

  // storage
  int? _free;

  // preview
  int? _previewVidId;
  VideoPlayerController? _vc;
  String? _prevPath;
  bool _prevBusy = false;
  double _prevProg = 0;
  String? _prevMsg;
  int? _prevBytes;
  int? _prevMeasured;
  bool _prevStale = false;

  // job
  bool _running = false;
  bool _cancel = false;
  double _jobProg = 0;
  String _stage = '';
  DateTime? _jobStart;
  DateTime _lastSvc = DateTime.fromMillisecondsSinceEpoch(0);
  JobResult? _result;
  final List<String> _failed = [];
  void Function(double)? _zipCb;
  String _lastLog = '';

  @override
  void initState() {
    super.initState();
    _native.setMethodCallHandler((call) async {
      if (call.method == 'zipProgress') {
        final a = call.arguments as Map;
        final done = (a['done'] as num).toDouble();
        final total = (a['total'] as num).toDouble();
        _zipCb?.call(total > 0 ? done / total : 0);
      }
      return null;
    });
    _refreshFree();
    _initialCleanup();
  }

  @override
  void dispose() {
    _native.setMethodCallHandler(null);
    _vc?.dispose();
    super.dispose();
  }

  void _set(VoidCallback fn) {
    if (mounted) setState(fn);
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _initialCleanup() async {
    try {
      final work = await _native.invokeMethod<String>('workDir');
      if (work == null) return;
      await for (final e in Directory(work).list()) {
        if (e is File) await _deleteQuiet(e.path);
      }
    } catch (_) {}
  }

  Future<int?> _freeNow() async {
    try {
      return (await _native.invokeMethod<num>('freeSpace'))?.toInt();
    } catch (_) {
      return null;
    }
  }

  Future<void> _refreshFree() async {
    final f = await _freeNow();
    _set(() => _free = f);
  }

  // ───────────── planning / estimates ─────────────

  Vid? get _target {
    if (_vids.isEmpty) return null;
    for (final v in _vids) {
      if (v.id == _previewVidId) return v;
    }
    return _vids.first;
  }

  Plan _plan(Vid v) {
    final target = _levels[_quality];
    double w = math.max(v.w, 2).toDouble();
    double h = math.max(v.h, 2).toDouble();
    final landscape = w >= h;
    final short = math.min(w, h);
    int? scaleTo;
    if (target != null && short > target * 1.05) {
      final f = target / short;
      w *= f;
      h *= f;
      scaleTo = target;
    }
    int even(double x) => math.max(2, (x / 2).round() * 2);
    final ow = even(w), oh = even(h);
    final fps = math.min(v.fps <= 0 ? 30.0 : v.fps, 60.0);
    final hevc = _codec == Codec.hevc;
    final px = ow * oh;
    final resFactor = px <= 640 * 360 * 1.1
        ? 1.35
        : px <= 854 * 480 * 1.1
            ? 1.2
            : px <= 1280 * 720 * 1.1
                ? 1.1
                : 1.0;
    double bps = px * fps * (hevc ? 0.04 : 0.065) * resFactor;
    bps *= 1 + 0.12 * (_speed - 1);
    if (_hw) bps *= 1.2;
    if (v.vBps > 0) bps = math.min(bps, v.vBps.toDouble());
    final vBps = bps.clamp(150000.0, 25000000.0).round();
    final aBps = v.hasAudio ? (_quality <= 2 ? 96000 : 64000) : 0;
    final outDurMs = (v.durMs / _speed).round();
    final bytes = ((vBps + aBps) * (outDurMs / 1000) / 8 * 1.02).round();
    return Plan(
      outW: ow,
      outH: oh,
      vBps: vBps,
      aBps: aBps,
      outDurMs: outDurMs,
      bytes: bytes,
      fps: fps,
      scaleTo: scaleTo,
      landscape: landscape,
    );
  }

  int _need(List<Plan> plans) {
    if (plans.isEmpty) return 0;
    final sum = plans.fold<int>(0, (a, p) => a + p.bytes);
    final mx = plans.fold<int>(0, (a, p) => math.max(a, p.bytes));
    return (sum * 1.03 + mx * 1.1 + 256 * 1024 * 1024).round();
  }

  void _changed() {
    if (_vc != null) _prevStale = true;
  }

  // ───────────── picking & probing ─────────────

  Future<void> _openPicker() async {
    bool ok = false;
    try {
      ok = await _native.invokeMethod<bool>('ensurePermissions') ?? false;
    } catch (_) {}
    if (!ok) {
      _toast('Video access permission is required.');
      return;
    }
    if (!mounted) return;
    final picked = await showModalBottomSheet<List<Vid>>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => _PickerSheet(selectedIds: _vids.map((v) => v.id).toSet()),
    );
    if (picked == null) return;
    final old = {for (final v in _vids) v.id: v};
    final merged = <Vid>[];
    for (final p in picked) {
      final existing = old[p.id];
      if (existing != null) {
        merged.add(existing);
      } else {
        merged.add(p);
        _probeChain = _probeChain.then((_) => _probe(p));
      }
    }
    _set(() {
      _vids
        ..clear()
        ..addAll(merged);
      _changed();
    });
    _refreshFree();
  }

  void _remove(Vid v) {
    _set(() {
      _vids.removeWhere((x) => x.id == v.id);
      if (_previewVidId == v.id) _previewVidId = null;
      _changed();
    });
    _refreshFree();
  }

  int _rotationOf(Map? p) {
    if (p == null) return 0;
    num? r;
    final tags = p['tags'];
    if (tags is Map && tags['rotate'] != null) r = num.tryParse('${tags['rotate']}');
    final sd = p['side_data_list'];
    if (r == null && sd is List) {
      for (final e in sd) {
        if (e is Map && e['rotation'] != null) {
          r = num.tryParse('${e['rotation']}');
          break;
        }
      }
    }
    return ((((r ?? 0).round()) % 360) + 360) % 360;
  }

  double _parseFps(String? s) {
    if (s == null) return 0;
    final parts = s.split('/');
    final a = double.tryParse(parts[0]) ?? 0;
    final b = parts.length > 1 ? (double.tryParse(parts[1]) ?? 1) : 1;
    return b == 0 ? 0 : a / b;
  }

  Future<void> _probe(Vid v) async {
    _set(() => v.probing = true);
    try {
      final s = await FFprobeKit.getMediaInformation(v.path);
      final info = s.getMediaInformation();
      if (info != null) {
        bool audio = false;
        bool gotVideo = false;
        for (final st in info.getStreams()) {
          final type = st.getType();
          final props = st.getAllProperties();
          if (type == 'audio') audio = true;
          if (type == 'video' && !gotVideo) {
            final disp = props?['disposition'];
            if (disp is Map && '${disp['attached_pic']}' == '1') continue;
            gotVideo = true;
            int? w = st.getWidth();
            int? h = st.getHeight();
            final rot = _rotationOf(props);
            if (w != null && h != null) {
              if (rot == 90 || rot == 270) {
                final t = w;
                w = h;
                h = t;
              }
              v.w = w;
              v.h = h;
            }
            double fps = _parseFps(st.getAverageFrameRate());
            if (fps <= 0) fps = _parseFps('${props?['r_frame_rate']}');
            if (fps > 0) v.fps = fps;
            v.vBps = int.tryParse(st.getBitrate() ?? '') ?? 0;
          }
        }
        v.hasAudio = audio;
        if (v.durMs <= 0) {
          final d = double.tryParse(info.getDuration() ?? '');
          if (d != null) v.durMs = (d * 1000).round();
        }
        if (v.vBps <= 0 && v.durMs > 0) {
          v.vBps = math.max(0, (v.size * 8 / (v.durMs / 1000) - (audio ? 128000 : 0)).round());
        }
      }
    } catch (_) {}
    _set(() {
      v.probing = false;
      _changed();
    });
  }

  // ───────────── encoding ─────────────

  String _atempo(double s) {
    if (s <= 2.0) return 'atempo=${s.toStringAsFixed(3)}';
    return 'atempo=2.0,atempo=${(s / 2).toStringAsFixed(3)}';
  }

  List<String> _args(Vid v, Plan p, String out, bool hw, double ss, double? span) {
    final hevc = _codec == Codec.hevc;
    final a = <String>['-hide_banner', '-y'];
    if (ss > 0) a.addAll(['-ss', ss.toStringAsFixed(2)]);
    if (span != null) a.addAll(['-t', span.toStringAsFixed(2)]);
    a.addAll(['-i', v.path, '-map', '0:v:0']);
    if (v.hasAudio) a.addAll(['-map', '0:a:0?']);
    a.addAll(['-sn', '-dn', '-map_metadata', '-1', '-map_chapters', '-1']);

    final vf = <String>[];
    if (_speed != 1.0) {
      vf.add('setpts=PTS/${_speed.toStringAsFixed(3)}');
      vf.add('fps=${p.fps.toStringAsFixed(3)}');
    }
    if (p.scaleTo != null) {
      vf.add(p.landscape ? 'scale=-2:${p.scaleTo}' : 'scale=${p.scaleTo}:-2');
    }
    vf.add('format=yuv420p');
    a.addAll(['-vf', vf.join(',')]);

    final vb = '${p.vBps}';
    if (hw) {
      a.addAll(['-c:v', hevc ? 'hevc_mediacodec' : 'h264_mediacodec', '-b:v', vb]);
    } else if (hevc) {
      a.addAll(['-c:v', 'libx265', '-preset', 'superfast', '-b:v', vb, '-x265-params', 'log-level=error']);
    } else {
      a.addAll([
        '-c:v', 'libx264', '-preset', 'veryfast', '-b:v', vb,
        '-maxrate', '${(p.vBps * 1.6).round()}', '-bufsize', '${p.vBps * 2}',
      ]);
    }
    if (hevc) a.addAll(['-tag:v', 'hvc1']);

    if (v.hasAudio) {
      a.addAll(['-c:a', 'aac', '-b:a', '${p.aBps}', '-ac', '2']);
      if (_speed != 1.0) a.addAll(['-af', _atempo(_speed)]);
    }
    a.addAll(['-max_muxing_queue_size', '4096', '-f', 'mp4', out]);
    return a;
  }

  Future<EncResult> _encode(
    Vid v,
    Plan p,
    String out, {
    double ss = 0,
    double? span,
    required void Function(double) onProg,
  }) async {
    final srcSpan = span ?? (v.durMs / 1000.0 - ss);
    final expectOutMs = math.max(1.0, srcSpan / _speed * 1000);
    final modes = _hw ? [true, false] : [false];
    for (final hw in modes) {
      if (_cancel) return EncResult.cancelled;
      await _deleteQuiet(out);
      final comp = Completer<ReturnCode?>();
      await FFmpegKit.executeWithArgumentsAsync(
        _args(v, p, out, hw, ss, span),
        (session) async {
          try {
            _lastLog = await session.getAllLogsAsString() ?? '';
          } catch (_) {}
          comp.complete(await session.getReturnCode());
        },
        null,
        (stat) {
          final num? t = stat.getTime();
          final ms = (t ?? 0).toDouble();
          if (ms > 0) onProg((ms / expectOutMs).clamp(0.0, 1.0));
        },
      );
      final rc = await comp.future;
      if (_cancel || ReturnCode.isCancel(rc)) return EncResult.cancelled;
      if (ReturnCode.isSuccess(rc)) {
        final f = File(out);
        if (await f.exists() && await f.length() > 1024) return EncResult.ok;
      }
    }
    return EncResult.failed;
  }

  // ───────────── preview ─────────────

  Future<void> _makePreview() async {
    final v = _target;
    if (v == null || _prevBusy || _running) return;
    final work = await _native.invokeMethod<String>('workDir') ?? '';
    final old = _vc;
    final oldPath = _prevPath;
    _set(() {
      _vc = null;
      _prevPath = null;
      _prevBusy = true;
      _prevProg = 0;
      _prevMsg = null;
      _prevStale = false;
    });
    await WidgetsBinding.instance.endOfFrame;
    await old?.dispose();
    if (oldPath != null) await _deleteQuiet(oldPath);

    final plan = _plan(v);
    final total = v.durMs / 1000.0;
    final spanSrc = 60.0 * _speed;
    final span = math.min(spanSrc, total);
    final ss = total > spanSrc ? math.max(0.0, math.min(total * 0.3, total - spanSrc)) : 0.0;
    final out = '$work/preview_${DateTime.now().millisecondsSinceEpoch}.mp4';
    _cancel = false;
    final r = await _encode(v, plan, out, ss: ss, span: span, onProg: (x) => _set(() => _prevProg = x));
    if (!mounted) return;
    if (r == EncResult.ok) {
      try {
        final size = await File(out).length();
        final c = VideoPlayerController.file(File(out));
        await c.initialize();
        await c.setLooping(true);
        await c.play();
        final outSec = span / _speed;
        final measured = (size / outSec * (v.durMs / _speed / 1000)).round();
        _set(() {
          _vc = c;
          _prevPath = out;
          _prevBytes = size;
          _prevMeasured = measured;
          _prevBusy = false;
        });
      } catch (e) {
        await _deleteQuiet(out);
        _set(() {
          _prevBusy = false;
          _prevMsg = 'Could not play the preview: $e';
        });
      }
    } else {
      await _deleteQuiet(out);
      final tail = _lastLog.length > 300 ? _lastLog.substring(_lastLog.length - 300) : _lastLog;
      _set(() {
        _prevBusy = false;
        _prevMsg = r == EncResult.cancelled ? 'Preview cancelled.' : 'Preview failed.\n$tail';
      });
    }
  }

  void _cancelPreview() {
    _cancel = true;
    FFmpegKit.cancel();
  }

  // ───────────── main job ─────────────

  String _entryName(String name, Set<String> used) {
    var base = name.contains('.') ? name.substring(0, name.lastIndexOf('.')) : name;
    base = base.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    var cand = '$base.mp4';
    var n = 2;
    while (used.contains(cand.toLowerCase())) {
      cand = '$base ($n).mp4';
      n++;
    }
    used.add(cand.toLowerCase());
    return cand;
  }

  void _pushNotif(String text) {
    final now = DateTime.now();
    if (now.difference(_lastSvc).inMilliseconds < 1500) return;
    _lastSvc = now;
    unawaited(_svc('serviceUpdate', {
      'title': 'VidShrink',
      'text': text,
      'progress': (_jobProg * 100).round(),
    }));
  }

  Future<void> _noSpaceDialog(int need) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        icon: const Icon(Icons.sd_storage_outlined),
        title: const Text('Not enough free space'),
        content: Text(
            'Needed (estimate): ${fmtBytes(need)}\nAvailable: ${fmtBytes(_free ?? 0)}\n\n'
            'Free some space or pick a lower quality / fewer videos.'),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))],
      ),
    );
  }

  void _cancelJob() {
    _cancel = true;
    FFmpegKit.cancel();
    unawaited(_svc('sevenZCancel'));
    _set(() => _stage = 'Cancelling…');
  }

  Future<void> _start() async {
    if (_running || _vids.isEmpty || _prevBusy) return;
    await _refreshFree();
    final jobs = List<Vid>.of(_vids);
    final plans = jobs.map(_plan).toList();
    final need = _need(plans);
    if (_free != null && _free! < need) {
      await _noSpaceDialog(need);
      return;
    }
    await _vc?.pause();
    _cancel = false;
    _set(() {
      _running = true;
      _result = null;
      _jobProg = 0;
      _stage = 'Starting…';
      _failed.clear();
      _jobStart = DateTime.now();
    });

    final work = await _native.invokeMethod<String>('workDir') ?? '';
    await _initialCleanup();
    await _svc('serviceStart', {'title': 'VidShrink', 'text': 'Starting…'});

    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final stamp = '${now.year}${two(now.month)}${two(now.day)}_${two(now.hour)}${two(now.minute)}';
    final weights = plans.map((p) => math.max(p.outDurMs, 1000).toDouble()).toList();
    final totalW = weights.fold(0.0, (a, b) => a + b);
    double doneW = 0;
    int added = 0;
    int srcBytes = 0;
    String? error;
    String? label;
    bool opened = false;
    final used = <String>{};
    JobResult res;

    try {
      label = await _native.invokeMethod<String>('sevenZOpen', {
        'name': 'VidShrink_$stamp.7z',
        'ultra': _ultra,
      });
      opened = true;

      for (var i = 0; i < jobs.length && !_cancel; i++) {
        final v = jobs[i], p = plans[i];
        void upd(double frac) {
          _jobProg = ((doneW + weights[i] * frac) / totalW).clamp(0.0, 1.0);
          _pushNotif(_stage);
          if (mounted) setState(() {});
        }

        final f = await _freeNow();
        if (f != null && f < p.bytes * 1.15 + 150 * 1024 * 1024) {
          error = 'Stopped: not enough free space for "${v.name}".';
          break;
        }
        final tmp = '$work/c_$i.mp4';
        _set(() => _stage = 'Compressing ${i + 1}/${jobs.length} · ${v.name}');
        final r = await _encode(v, p, tmp, onProg: (x) => upd(x * 0.85));
        if (r == EncResult.cancelled) {
          await _deleteQuiet(tmp);
          break;
        }
        if (r == EncResult.failed) {
          _failed.add(v.name);
          await _deleteQuiet(tmp);
          doneW += weights[i];
          continue;
        }

        _set(() => _stage = 'Archiving ${i + 1}/${jobs.length} · ${v.name}');
        _zipCb = (fr) => upd(0.85 + 0.15 * fr);
        try {
          await _native.invokeMethod('sevenZAdd', {
            'path': tmp,
            'entry': _entryName(v.name, used),
          });
          added++;
          srcBytes += v.size;
        } on PlatformException catch (e) {
          if (!_cancel) error = 'Archive error: ${e.message}';
          await _deleteQuiet(tmp);
          break;
        } finally {
          _zipCb = null;
        }
        await _deleteQuiet(tmp);
        doneW += weights[i];
        upd(0);
      }

      if (_cancel) {
        await _svc('sevenZAbort');
        res = JobResult(false, 'Cancelled', 'Nothing was saved. Temporary files were removed.');
      } else if (added == 0) {
        await _svc('sevenZAbort');
        res = JobResult(false, 'Nothing was compressed',
            error ?? 'Every video failed to encode.\n${_lastLog.length > 300 ? _lastLog.substring(_lastLog.length - 300) : _lastLog}');
      } else {
        _set(() => _stage = 'Finishing archive…');
        final size = await _native.invokeMethod<num>('sevenZFinish') ?? 0;
        final saved = srcBytes > 0 ? (1 - size / srcBytes) * 100 : 0;
        res = JobResult(
          true,
          error == null ? 'Done' : 'Finished with a warning',
          'Saved to $label\n'
          '$added video${added == 1 ? '' : 's'}: ${fmtBytes(srcBytes)} → ${fmtBytes(size)} (−${saved.toStringAsFixed(0)}%)'
          '${error != null ? '\n$error' : ''}',
        );
      }
    } on PlatformException catch (e) {
      if (opened) await _svc('sevenZAbort');
      res = JobResult(false, 'Failed', e.message ?? e.toString());
    } catch (e) {
      if (opened) await _svc('sevenZAbort');
      res = JobResult(false, 'Failed', e.toString());
    }

    await _initialCleanup();
    await _svc('serviceStop', {
      'title': res.ok ? 'Compression finished' : 'Compression stopped',
      'text': res.ok ? res.detail.split('\n').first : res.title,
    });
    _set(() {
      _running = false;
      _jobProg = res.ok ? 1 : _jobProg;
      _result = res;
    });
    _refreshFree();
  }

  // ───────────── UI ─────────────

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    return PopScope(
      canPop: !_running,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _svc('toBackground');
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('VidShrink'), centerTitle: false),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          children: [
            if (_running || _result != null) _jobCard(cs, tt),
            _videosCard(cs, tt),
            IgnorePointer(
              ignoring: _running,
              child: Opacity(
                opacity: _running ? 0.5 : 1,
                child: Column(children: [
                  _qualityCard(cs, tt),
                  _speedCard(cs, tt),
                  _previewCard(cs, tt),
                  _summaryCard(cs, tt),
                ]),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Material(
          color: cs.surfaceContainer,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: SizedBox(
                width: double.infinity,
                child: _running
                    ? FilledButton.tonalIcon(
                        onPressed: _cancelJob,
                        icon: const Icon(Icons.stop_circle_outlined),
                        label: const Text('Cancel'),
                      )
                    : FilledButton.icon(
                        onPressed: (_vids.isEmpty || _prevBusy) ? null : _start,
                        icon: const Icon(Icons.compress),
                        label: Text(_vids.isEmpty
                            ? 'Select videos to start'
                            : 'Compress ${_vids.length} video${_vids.length == 1 ? '' : 's'} → 7z'),
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _section(ColorScheme cs, TextTheme tt, String title, IconData icon, Widget child,
      {Widget? trailing}) {
    return Card.filled(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(icon, color: cs.primary),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: tt.titleMedium)),
            if (trailing != null) trailing,
          ]),
          const SizedBox(height: 12),
          child,
        ]),
      ),
    );
  }

  Widget _jobCard(ColorScheme cs, TextTheme tt) {
    if (_running) {
      final el = DateTime.now().difference(_jobStart ?? DateTime.now());
      String eta = '';
      if (_jobProg > 0.02) {
        final rem = el.inSeconds / _jobProg * (1 - _jobProg);
        eta = ' · ETA ${fmtDur(rem * 1000)}';
      }
      return _section(
        cs,
        tt,
        'Working…',
        Icons.hourglass_top,
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(_stage, maxLines: 2, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 12),
          LinearProgressIndicator(value: _jobProg > 0 ? _jobProg : null, minHeight: 8),
          const SizedBox(height: 8),
          Text('${(_jobProg * 100).toStringAsFixed(1)}% · elapsed ${fmtDur(el.inMilliseconds)}$eta',
              style: tt.bodySmall),
          const SizedBox(height: 8),
          Text(
            'Keeps running in the background. Leave with Back/Home — don\'t swipe the app away from recents.',
            style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant),
          ),
        ]),
      );
    }
    final r = _result!;
    return Card(
      color: r.ok ? cs.primaryContainer : cs.errorContainer,
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(r.ok ? Icons.check_circle : Icons.error_outline,
                color: r.ok ? cs.onPrimaryContainer : cs.onErrorContainer),
            const SizedBox(width: 12),
            Expanded(
                child: Text(r.title,
                    style: tt.titleMedium?.copyWith(
                        color: r.ok ? cs.onPrimaryContainer : cs.onErrorContainer))),
            IconButton(
                onPressed: () => _set(() => _result = null), icon: const Icon(Icons.close)),
          ]),
          const SizedBox(height: 8),
          Text(r.detail,
              style: tt.bodyMedium?.copyWith(
                  color: r.ok ? cs.onPrimaryContainer : cs.onErrorContainer)),
          if (_failed.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('Failed: ${_failed.join(', ')}',
                style: tt.bodySmall?.copyWith(
                    color: r.ok ? cs.onPrimaryContainer : cs.onErrorContainer)),
          ],
        ]),
      ),
    );
  }

  Widget _videosCard(ColorScheme cs, TextTheme tt) {
    return _section(
      cs,
      tt,
      'Videos',
      Icons.video_library_outlined,
      _vids.isEmpty
          ? Text('Pick the videos you want to compress (MP4, MKV, H.264, H.265…).',
              style: tt.bodyMedium?.copyWith(color: cs.onSurfaceVariant))
          : Column(children: [for (final v in _vids) _vidTile(v, cs, tt)]),
      trailing: FilledButton.tonalIcon(
        onPressed: _running ? null : _openPicker,
        icon: const Icon(Icons.add),
        label: Text(_vids.isEmpty ? 'Select' : 'Edit'),
      ),
    );
  }

  Widget _vidTile(Vid v, ColorScheme cs, TextTheme tt) {
    final p = _plan(v);
    final isTarget = _target?.id == v.id;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: SizedBox(width: 64, height: 64, child: Thumb(id: v.id)),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(v.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: tt.titleSmall),
            Row(children: [
              Flexible(
                child: Text('${fmtDur(v.durMs)} · ${fmtBytes(v.size)} · ${v.w}×${v.h}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
              ),
              if (v.probing) ...[
                const SizedBox(width: 6),
                const SizedBox(
                    width: 10, height: 10, child: CircularProgressIndicator(strokeWidth: 2)),
              ],
            ]),
            Row(children: [
              Icon(Icons.arrow_forward, size: 14, color: cs.primary),
              const SizedBox(width: 4),
              Flexible(
                child: Text(
                    '${fmtDur(p.outDurMs)} · ~${fmtBytes(p.bytes)} · ${p.outW}×${p.outH}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: tt.bodySmall?.copyWith(
                        color: cs.primary, fontWeight: FontWeight.w600)),
              ),
            ]),
          ]),
        ),
        IconButton(
          tooltip: 'Use for preview',
          onPressed: _running ? null : () => _set(() {
                _previewVidId = v.id;
                _changed();
              }),
          icon: Icon(isTarget ? Icons.play_circle : Icons.play_circle_outline,
              color: isTarget ? cs.primary : null),
        ),
        IconButton(
          tooltip: 'Remove',
          onPressed: _running ? null : () => _remove(v),
          icon: const Icon(Icons.close),
        ),
      ]),
    );
  }

  Widget _qualityCard(ColorScheme cs, TextTheme tt) {
    final t = _target;
    final plan = t == null ? null : _plan(t);
    return _section(
      cs,
      tt,
      'Quality',
      Icons.high_quality_outlined,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Slider(
          value: _quality.toDouble(),
          min: 0,
          max: 4,
          divisions: 4,
          label: _levelNames[_quality],
          onChanged: (x) => _set(() {
            _quality = x.round();
            _changed();
          }),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            for (var i = 0; i < _levelNames.length; i++)
              Text(_levelNames[i],
                  style: tt.labelSmall?.copyWith(
                      color: i == _quality ? cs.primary : cs.onSurfaceVariant,
                      fontWeight: i == _quality ? FontWeight.bold : FontWeight.normal)),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          plan == null
              ? 'Bitrate is chosen automatically for a clean picture at each size.'
              : 'Video ≈ ${fmtRate(plan.vBps)} · ${plan.outW}×${plan.outH}'
                  '${plan.aBps > 0 ? ' · audio ${plan.aBps ~/ 1000} kbps' : ''}',
          style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<Codec>(
            segments: const [
              ButtonSegment(value: Codec.hevc, label: Text('H.265 · smaller')),
              ButtonSegment(value: Codec.h264, label: Text('H.264 · compatible')),
            ],
            selected: {_codec},
            onSelectionChanged: (s) => _set(() {
              _codec = s.first;
              _changed();
            }),
          ),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Hardware encoder'),
          subtitle: const Text(
              'Much faster. Falls back to software automatically if the phone\'s encoder fails.'),
          value: _hw,
          onChanged: (x) => _set(() {
            _hw = x;
            _changed();
          }),
        ),
      ]),
    );
  }

  Widget _speedCard(ColorScheme cs, TextTheme tt) {
    return _section(
      cs,
      tt,
      'Speed',
      Icons.speed,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Slider(
          value: _speed,
          min: 1,
          max: 3,
          divisions: 8,
          label: '${_speed.toStringAsFixed(2)}x',
          onChanged: (x) => _set(() {
            _speed = (x * 4).round() / 4;
            _changed();
          }),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('1x', style: tt.labelSmall),
            Text('${_speed.toStringAsFixed(2)}x',
                style: tt.labelLarge?.copyWith(color: cs.primary, fontWeight: FontWeight.bold)),
            Text('3x', style: tt.labelSmall),
          ],
        ),
        const SizedBox(height: 4),
        Text('Video and audio are sped up; output length = original ÷ speed.',
            style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
      ]),
    );
  }

  Widget _previewCard(ColorScheme cs, TextTheme tt) {
    final t = _target;
    final c = _vc;
    return _section(
      cs,
      tt,
      'Preview (1 min)',
      Icons.preview_outlined,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
          t == null
              ? 'Select a video to preview the current settings.'
              : 'Sample from: ${t.name}\n(tap ▶ on another video above to change it)',
          style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant),
        ),
        const SizedBox(height: 12),
        if (_prevBusy) ...[
          LinearProgressIndicator(value: _prevProg > 0 ? _prevProg : null, minHeight: 6),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: Text('Rendering preview… ${(_prevProg * 100).round()}%')),
            TextButton(onPressed: _cancelPreview, child: const Text('Cancel')),
          ]),
        ] else
          SizedBox(
            width: double.infinity,
            child: FilledButton.tonalIcon(
              onPressed: t == null || _running ? null : _makePreview,
              icon: const Icon(Icons.refresh),
              label: const Text('Update preview'),
            ),
          ),
        if (_prevMsg != null) ...[
          const SizedBox(height: 8),
          Text(_prevMsg!, style: tt.bodySmall?.copyWith(color: cs.error)),
        ],
        if (c != null && !_prevBusy) ...[
          const SizedBox(height: 12),
          if (_prevStale)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Chip(
                avatar: const Icon(Icons.info_outline, size: 18),
                label: const Text('Settings changed — tap Update preview'),
              ),
            ),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(
              aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio,
              child: Stack(alignment: Alignment.center, children: [
                VideoPlayer(c),
                ValueListenableBuilder<VideoPlayerValue>(
                  valueListenable: c,
                  builder: (_, val, __) => IconButton.filledTonal(
                    onPressed: () => val.isPlaying ? c.pause() : c.play(),
                    icon: Icon(val.isPlaying ? Icons.pause : Icons.play_arrow),
                  ),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          VideoProgressIndicator(c, allowScrubbing: true),
          const SizedBox(height: 8),
          Text(
            'Sample: ${fmtBytes(_prevBytes ?? 0)} for 1 min → whole video ≈ ${fmtBytes(_prevMeasured ?? 0)} (measured)',
            style: tt.bodySmall?.copyWith(color: cs.primary, fontWeight: FontWeight.w600),
          ),
        ],
      ]),
    );
  }

  Widget _stat(TextTheme tt, ColorScheme cs, String label, String big, String small) {
    return Expanded(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: tt.labelMedium?.copyWith(color: cs.onSurfaceVariant)),
        Text(big, style: tt.titleLarge),
        Text(small, style: tt.bodySmall),
      ]),
    );
  }

  Widget _summaryCard(ColorScheme cs, TextTheme tt) {
    final plans = _vids.map(_plan).toList();
    final srcBytes = _vids.fold<int>(0, (a, v) => a + v.size);
    final srcMs = _vids.fold<int>(0, (a, v) => a + v.durMs);
    final estBytes = plans.fold<int>(0, (a, p) => a + p.bytes);
    final estMs = plans.fold<int>(0, (a, p) => a + p.outDurMs);
    final need = _need(plans);
    final enough = _free == null || _free! >= need;
    final saving = srcBytes > 0 ? (1 - estBytes / srcBytes) * 100 : 0;
    return _section(
      cs,
      tt,
      'Summary',
      Icons.summarize_outlined,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _stat(tt, cs, 'Videos', '${_vids.length}', 'selected'),
          _stat(tt, cs, 'Before', fmtBytes(srcBytes), fmtDur(srcMs)),
          _stat(tt, cs, 'After (est.)', fmtBytes(estBytes), fmtDur(estMs)),
        ]),
        if (_vids.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text(
            saving >= 0
                ? 'About ${saving.toStringAsFixed(0)}% smaller (${fmtBytes(srcBytes - estBytes)} saved)'
                : 'Estimated larger than the original — lower the quality.',
            style: tt.bodyMedium?.copyWith(color: cs.primary, fontWeight: FontWeight.w600),
          ),
        ],
        const SizedBox(height: 8),
        Row(children: [
          Icon(enough ? Icons.sd_storage_outlined : Icons.warning_amber_rounded,
              size: 18, color: enough ? cs.onSurfaceVariant : cs.error),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Free: ${_free == null ? '…' : fmtBytes(_free!)} · Needed: ${_vids.isEmpty ? '—' : fmtBytes(need)}'
              '${enough ? '' : '  — not enough space'}',
              style: tt.bodySmall?.copyWith(color: enough ? cs.onSurfaceVariant : cs.error),
            ),
          ),
        ]),
        const Divider(height: 24),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Ultra 7z (LZMA2, level 9)'),
          subtitle: const Text(
              'Maximum compression, slower. Videos are already compressed, so extra savings are tiny — switch off for a fast "store" archive.'),
          value: _ultra,
          onChanged: (x) => setState(() => _ultra = x),
        ),
      ]),
    );
  }
}

// ───────────────────────── thumbnail ─────────────────────────

class Thumb extends StatelessWidget {
  const Thumb({super.key, required this.id});
  final int id;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return FutureBuilder<Uint8List?>(
      future: _thumbOf(id),
      builder: (c, s) {
        final d = s.data;
        if (d != null) return Image.memory(d, fit: BoxFit.cover, gaplessPlayback: true);
        return ColoredBox(
          color: cs.surfaceContainerHighest,
          child: Icon(Icons.movie_outlined, color: cs.onSurfaceVariant),
        );
      },
    );
  }
}

// ───────────────────────── selection panel ─────────────────────────

class _PickerSheet extends StatefulWidget {
  const _PickerSheet({required this.selectedIds});
  final Set<int> selectedIds;
  @override
  State<_PickerSheet> createState() => _PickerSheetState();
}

class _PickerSheetState extends State<_PickerSheet> {
  List<Vid> _all = [];
  late final Set<int> _sel = {...widget.selectedIds};
  String _q = '';
  bool _loading = true;
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final raw = await _native.invokeMethod<List<dynamic>>('listVideos') ?? [];
      final list = raw.map((e) => Vid.fromMap(e as Map<dynamic, dynamic>)).toList();
      if (!mounted) return;
      setState(() {
        _all = list;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _err = e.toString();
        _loading = false;
      });
    }
  }

  List<Vid> get _filtered => _q.isEmpty
      ? _all
      : _all.where((v) => v.name.toLowerCase().contains(_q.toLowerCase())).toList();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final list = _filtered;
    final selBytes = _all.where((v) => _sel.contains(v.id)).fold<int>(0, (a, v) => a + v.size);
    final allSelected = list.isNotEmpty && list.every((v) => _sel.contains(v.id));
    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.9,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Select videos', style: tt.titleLarge),
                Text('${_sel.length} selected · ${fmtBytes(selBytes)}',
                    style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
              ]),
            ),
            TextButton(
              onPressed: list.isEmpty
                  ? null
                  : () => setState(() {
                        if (allSelected) {
                          for (final v in list) {
                            _sel.remove(v.id);
                          }
                        } else {
                          for (final v in list) {
                            _sel.add(v.id);
                          }
                        }
                      }),
              child: Text(allSelected ? 'Clear' : 'Select all'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.pop(context, _all.where((v) => _sel.contains(v.id)).toList()),
              child: const Text('Done'),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: TextField(
            onChanged: (s) => setState(() => _q = s),
            decoration: InputDecoration(
              hintText: 'Search videos',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
            ),
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _err != null
                  ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_err!)))
                  : list.isEmpty
                      ? const Center(child: Text('No videos found'))
                      : GridView.builder(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            mainAxisSpacing: 8,
                            crossAxisSpacing: 8,
                            childAspectRatio: 0.78,
                          ),
                          itemCount: list.length,
                          itemBuilder: (_, i) => _gridTile(list[i], cs, tt),
                        ),
        ),
      ]),
    );
  }

  Widget _gridTile(Vid v, ColorScheme cs, TextTheme tt) {
    final on = _sel.contains(v.id);
    return GestureDetector(
      onTap: () => setState(() => on ? _sel.remove(v.id) : _sel.add(v.id)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Stack(fit: StackFit.expand, children: [
              Thumb(id: v.id),
              if (on) ColoredBox(color: cs.primary.withAlpha(70)),
              Positioned(
                left: 6,
                bottom: 6,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                      color: Colors.black54, borderRadius: BorderRadius.circular(6)),
                  child: Text(fmtDur(v.durMs),
                      style: const TextStyle(color: Colors.white, fontSize: 11)),
                ),
              ),
              Positioned(
                right: 6,
                top: 6,
                child: Icon(on ? Icons.check_circle : Icons.circle_outlined,
                    color: on ? cs.primary : Colors.white, size: 24),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 4),
        Text(v.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: tt.labelMedium),
        Text(fmtBytes(v.size), style: tt.labelSmall?.copyWith(color: cs.onSurfaceVariant)),
      ]),
    );
  }
}
