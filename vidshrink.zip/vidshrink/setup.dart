// Run with:  dart setup.dart
// Creates the Android project, copies the app files in, patches Gradle, fetches packages.
import 'dart:io';

final sep = Platform.pathSeparator;

Future<void> run(String cmd, List<String> args) async {
  stdout.writeln('\n> $cmd ${args.join(' ')}');
  final p = await Process.start(cmd, args,
      runInShell: true, mode: ProcessStartMode.inheritStdio);
  final code = await p.exitCode;
  if (code != 0) {
    stderr.writeln('Command failed ($code). Fix the error above and re-run: dart setup.dart');
    exit(code);
  }
}

Future<void> copyDir(Directory from, Directory to) async {
  await for (final e in from.list(recursive: true, followLinks: false)) {
    if (e is! File) continue;
    final rel = e.path.substring(from.path.length + 1);
    final dest = File('${to.path}$sep$rel');
    await dest.parent.create(recursive: true);
    await e.copy(dest.path);
    stdout.writeln('  copied $rel');
  }
}

Future<void> main() async {
  final root = Directory.current;
  final overlay = Directory('${root.path}${sep}overlay');
  if (!overlay.existsSync()) {
    stderr.writeln('Run this from the vidshrink folder (the one containing "overlay").');
    exit(1);
  }

  if (!Directory('${root.path}${sep}android').existsSync()) {
    await run('flutter', [
      'create',
      '--platforms=android',
      '--org', 'com.vidshrink',
      '--project-name', 'vidshrink',
      '.',
    ]);
  }

  stdout.writeln('\nCopying app files…');
  await copyDir(overlay, root);

  // remove the default template test (it references the template app)
  final test = Directory('${root.path}${sep}test');
  if (test.existsSync()) test.deleteSync(recursive: true);

  // remove any other MainActivity the template generated
  final kotlinRoot = Directory('${root.path}${sep}android${sep}app${sep}src${sep}main${sep}kotlin');
  await for (final e in kotlinRoot.list(recursive: true)) {
    if (e is File &&
        e.path.endsWith('MainActivity.kt') &&
        !e.path.contains('${sep}vidshrink${sep}vidshrink$sep')) {
      e.deleteSync();
    }
  }
  final javaRoot = Directory('${root.path}${sep}android${sep}app${sep}src${sep}main${sep}java');
  if (javaRoot.existsSync()) {
    await for (final e in javaRoot.list(recursive: true)) {
      if (e is File && e.path.endsWith('MainActivity.java')) e.deleteSync();
    }
  }

  // ---- patch android/app/build.gradle(.kts) ----
  final kts = File('${root.path}${sep}android${sep}app${sep}build.gradle.kts');
  final groovy = File('${root.path}${sep}android${sep}app${sep}build.gradle');
  final isKts = kts.existsSync();
  final gradle = isKts ? kts : groovy;
  var s = gradle.readAsStringSync();

  if (!s.contains('VIDSHRINK_PATCHED')) {
    // minSdk 29 (MediaStore thumbnails + Downloads collection)
    s = s.replaceAllMapped(
      RegExp(r'minSdk(Version)?(\s*=\s*|\s+)flutter\.minSdkVersion'),
      (m) => 'minSdk${m[1] ?? ''}${m[2]}29',
    );

    // no R8 shrinking (commons-compress references optional classes)
    if (isKts) {
      s = s.replaceFirstMapped(
        RegExp(r'(signingConfig\s*=\s*signingConfigs\.getByName\("debug"\))'),
        (m) => '${m[1]}\n            isMinifyEnabled = false\n            isShrinkResources = false',
      );
      s += '''

// VIDSHRINK_PATCHED
dependencies {
    implementation("org.apache.commons:commons-compress:1.27.1")
    implementation("org.tukaani:xz:1.10")
}
''';
    } else {
      s = s.replaceFirstMapped(
        RegExp(r'(signingConfig\s+signingConfigs\.debug)'),
        (m) => '${m[1]}\n            minifyEnabled false\n            shrinkResources false',
      );
      s += '''

// VIDSHRINK_PATCHED
dependencies {
    implementation 'org.apache.commons:commons-compress:1.27.1'
    implementation 'org.tukaani:xz:1.10'
}
''';
    }
    gradle.writeAsStringSync(s);
    stdout.writeln('\nPatched ${gradle.path}');
  } else {
    stdout.writeln('\nGradle already patched.');
  }

  await run('flutter', ['pub', 'get']);

  stdout.writeln('''

All set. Next:
  flutter run --release                         (phone connected with USB debugging)
  flutter build apk --release --split-per-abi   (APK in build/app/outputs/flutter-apk/)
''');
}
